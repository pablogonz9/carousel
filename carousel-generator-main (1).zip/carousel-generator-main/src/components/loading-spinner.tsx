import { Loader2Icon } from "lucide-react";

export function LoadingSpinner() {
  return <Loader2Icon className="w-4 h-4 animate-spin" />;
}
