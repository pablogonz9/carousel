"use client";

import { FormProvider } from "react-hook-form";

export default FormProvider;
