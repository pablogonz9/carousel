export const SIZE = {
  width: 400,
  height: 500,
};
