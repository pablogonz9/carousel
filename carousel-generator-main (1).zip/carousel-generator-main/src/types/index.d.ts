// html2pdf doesn't have module declaration
declare module "html2pdf.js";
